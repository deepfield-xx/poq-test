//
//  ApiMock.swift
//  PoqHomeTestTests
//
//  Created by Tom on 08/12/2021.
//

import Foundation
@testable import PoqHomeTest

final class ApiMock: RepoFetchable {
    var isFetchReposFailed = false
    var isFetchReposCalled = false
    
    private func serializeJson<T>(filename fileName: String) -> T? where T: Codable {
        if let url = Bundle(for: type(of: self)).url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                return try decoder.decode(T.self, from: data)
            } catch {
                print("error: \(error)")
            }
        }
        
        return nil
    }
    
    func fetchRepos(_ completion: @escaping ([Repo]?, Error?) -> Void) {
        isFetchReposCalled = true
        
        guard isFetchReposFailed == false else {
            completion(nil, ApiError.invalidData)
            return
        }
        
        let repos: [Repo]? = serializeJson(filename: "repos")
        completion(repos, nil)
    }
}
