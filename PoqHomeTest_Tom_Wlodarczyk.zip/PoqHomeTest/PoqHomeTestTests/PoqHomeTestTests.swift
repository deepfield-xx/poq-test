//
//  PoqHomeTestTests.swift
//  PoqHomeTestTests
//
//  Created by Tom on 07/12/2021.
//

import XCTest
@testable import PoqHomeTest

class PoqHomeTestTests: XCTestCase {
    private let apiMock = ApiMock()
    private var sceneDelegate: SceneDelegate?
    private var mainViewController: MainViewController?

    override func setUpWithError() throws {
        sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate
        
        let dependencies = Dependencies(repoFetchable: apiMock)
        mainViewController = MainViewController(dependencies: dependencies)
        sceneDelegate?.window?.rootViewController = mainViewController
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testFetchingRepos() throws {
        let listViewController = mainViewController?.children.first as? ListViewController
        XCTAssertNotNil(listViewController)
        XCTAssertTrue(apiMock.isFetchReposCalled)
        XCTAssertEqual(listViewController?.tableView(UITableView(), numberOfRowsInSection: 0), 2)
        let firstCell = listViewController?.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? ListViewCell
        XCTAssertNotNil(firstCell)
        XCTAssertEqual(firstCell?.nameLabel.text,
                       "yajl-objc".firstUpper)
        XCTAssertEqual(firstCell?.descriptionLabel.text,
                       "Objective-C bindings for YAJL (Yet Another JSON Library) C library")
        XCTAssertTrue(mainViewController?.state == .loaded)
    }
    
    func testFetchingReposFailed() {
        apiMock.isFetchReposFailed = true
        mainViewController?.viewDidLoad()
        
        XCTAssertTrue(mainViewController?.state == .error)
    }
}
