//
//  XCTest+Utils.swift
//  PoqHomeTestTests
//
//  Created by Tom on 08/12/2021.
//
import XCTest

extension XCTestCase {
    func wait(_ delay: Double) {
        let exp = expectation(description: "")
        exp.isInverted = true
        
        waitForExpectations(timeout: TimeInterval(delay), handler: nil)
    }
}
