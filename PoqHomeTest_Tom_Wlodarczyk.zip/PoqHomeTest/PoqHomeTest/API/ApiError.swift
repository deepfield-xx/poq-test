//
//  ApiError.swift
//  PoqHomeTest
//
//  Created by Tom on 08/12/2021.
//

import Foundation

enum ApiError: Error {
    case invalidData
}
