//
//  Api.swift
//  PoqHomeTest
//
//  Created by Tom on 08/12/2021.
//

import Foundation


final class Api {
    private let session: URLSession
    
    init(_ session: URLSession = URLSession(configuration: .default)) {
        self.session = session
    }
}

extension Api: RepoFetchable {
    func fetchRepos(_ completion: @escaping ([Repo]?, Error?) -> Void) {
        let url = URL(string: "https://api.github.com/orgs/square/repos")!
        let task = session.dataTask(with: URLRequest(url: url)) { data, response, error in
            if error != nil {
                completion(nil, error)
            } else if let data = data,
                      let response = response as? HTTPURLResponse,
                      response.statusCode == 200
            {
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode([Repo].self, from: data)
                    DispatchQueue.main.async {
                        completion(result, nil)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, ApiError.invalidData)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    completion(nil, ApiError.invalidData)
                }
            }
        }
        
        task.resume()
    }
}
