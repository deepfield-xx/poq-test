//
//  Repo.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Foundation

// All properties are nullable cause I do not know the API contract

struct RepoOwner: Codable {
    let avatar_url: String?
}

struct Repo: Codable {
    let name: String?
    let description: String?
    let html_url: String?
    let owner: RepoOwner?
}
