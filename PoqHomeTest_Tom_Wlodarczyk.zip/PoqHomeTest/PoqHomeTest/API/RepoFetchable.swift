//
//  RepoFetchable.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Foundation

protocol RepoFetchable {
    func fetchRepos(_ completion: @escaping (_ repos: [Repo]?, _ error: Error?) -> Void)
}
