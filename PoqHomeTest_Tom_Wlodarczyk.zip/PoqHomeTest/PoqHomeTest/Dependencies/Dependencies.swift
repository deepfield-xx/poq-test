//
//  Dependencies.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Foundation

struct Dependencies {
    private(set) var repoFetchable: RepoFetchable
    
    init(repoFetchable: RepoFetchable = Api()) {
        self.repoFetchable = repoFetchable
    }
}
