//
//  NSObject+Extension.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Foundation

extension NSObject {
    class var className: String {
        return NSStringFromClass(self).components(separatedBy: ".").last!
    }
    
    var className: String {
        let thisType = type(of: self)
        return String(describing: thisType)
    }
}
