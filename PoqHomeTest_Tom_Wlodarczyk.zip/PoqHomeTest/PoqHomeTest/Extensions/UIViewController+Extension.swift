//
//  UIViewController+Extension.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import UIKit

extension UIViewController {
    func add(_ child: UIViewController) {
        addChild(child)
        view.addSubview(child.view)
        child.didMove(toParent: self)
    }
}
