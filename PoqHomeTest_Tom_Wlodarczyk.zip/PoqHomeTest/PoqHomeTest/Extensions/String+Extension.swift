//
//  String+Extension.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Foundation

extension String {
    var firstUpper: String {
        return dropLast(count-1).uppercased() + dropFirst()
    }
}
