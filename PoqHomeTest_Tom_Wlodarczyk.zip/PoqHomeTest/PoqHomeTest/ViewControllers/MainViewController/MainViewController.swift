//
//  MainViewController.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import UIKit

final class MainViewController: UIViewController, Statable {
    private let dependencies: Dependencies
    
    var state: State
    var indicator: UIActivityIndicatorView?
    
    init(dependencies: Dependencies) {
        self.state = .default
        self.dependencies = dependencies
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        initLoader()
        fetchRepos()
    }
    
    private func initLoader() {
        indicator = UIActivityIndicatorView(style: .large)
        indicator?.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(indicator!)
        
        let constraint = [indicator!.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                          indicator!.centerYAnchor.constraint(equalTo: view.centerYAnchor)]
        NSLayoutConstraint.activate(constraint)
    }

    private func fetchRepos() {
        state = .loading
        indicator?.startAnimating()
        dependencies.repoFetchable.fetchRepos { [weak self] repos, error in
            if let repos = repos {
                self?.state = .loaded
                self?.presentListView(repos)
            } else {
                self?.state = .error
                self?.presentErrorAlert()
            }
            self?.indicator?.stopAnimating()
        }
    }
    
    private func presentListView(_ repos: [Repo]) {
        let listViewController = ListViewController(repos: repos)
        add(listViewController)
    }

    private func presentErrorAlert() {
        let alert = UIAlertController(title: "Hold on", message: "Something went wrong", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Try again", style: .default, handler: { [weak self] _ in
            self?.fetchRepos()
        }))
        present(alert, animated: true, completion: nil)
    }
}

