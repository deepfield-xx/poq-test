//
//  ListViewCellCell.swift
//  PoqHomeTest
//
//  Created by Tom on 07/12/2021.
//

import Kingfisher
import UIKit

final class ListViewCell: UITableViewCell {
    private(set) var nameLabel = Subviews.nameLabel
    private(set) var descriptionLabel = Subviews.descriptionLabel
    private(set) var avatarImageView = Subviews.avatarImageView

    override func awakeFromNib() {
        super.awakeFromNib()
        
        setUp()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setUp()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        avatarImageView.image = nil
    }
    
    private func setUp() {
        selectionStyle = .none
        backgroundColor = .clear
        
        contentView.addSubview(nameLabel)
        contentView.addSubview(descriptionLabel)
        contentView.addSubview(avatarImageView)
        
        let constraints =
            [nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
             nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
             nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 15),
             nameLabel.bottomAnchor.constraint(equalTo: descriptionLabel.topAnchor, constant: -5),
             descriptionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
             descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15),
             descriptionLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -15),
             avatarImageView.widthAnchor.constraint(equalToConstant: 22),
             avatarImageView.heightAnchor.constraint(equalToConstant: 22),
             avatarImageView.centerYAnchor.constraint(equalTo: nameLabel.centerYAnchor),
             avatarImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15)]
        NSLayoutConstraint.activate(constraints)
    }
    
    func updateRow(_ repo: Repo, color: UIColor) {
        nameLabel.text = repo.name?.firstUpper ?? "-"
        descriptionLabel.text = repo.description?.firstUpper ?? "-"
        if let url = repo.owner?.avatar_url {
            // I used Kingfisher library to cache downloaded images locally
            avatarImageView.kf.setImage(with: URL(string: url)!)
        }
        
        contentView.backgroundColor = color
    }
}

private enum Subviews {
    static var nameLabel: UILabel {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 18)
        label.numberOfLines = 0
        label.textColor = .white
        
        return label
    }
    
    static var descriptionLabel: UILabel {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.numberOfLines = 0
        label.textColor = .white
        
        return label
    }
    
    static var avatarImageView: UIImageView {
        let view = UIImageView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.contentMode = .scaleAspectFit
        
        return view
    }
}
