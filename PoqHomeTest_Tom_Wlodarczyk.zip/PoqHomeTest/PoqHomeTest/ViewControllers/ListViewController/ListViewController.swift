import UIKit
import SafariServices

final class ListViewController: UIViewController {
    private let repos: [Repo]
    private(set) var tableView: UITableView
    
    init(repos: [Repo]) {
        self.repos = repos
        tableView = UITableView(frame: .zero, style: .plain)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(tableView)
        tableView.frame = view.bounds
        tableView.backgroundColor = .clear
        tableView.rowHeight = UITableView.automaticDimension
        tableView.contentInset = .zero
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorStyle = .none
        tableView.register(ListViewCell.self, forCellReuseIdentifier: ListViewCell.className)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        
        addBackgroundRectangles()
    }
    
    private func getColorFor(_ hue: CGFloat) -> UIColor {
        return UIColor(hue: hue, saturation: 0.6, brightness: 0.8, alpha: 1.0)
    }
    
    // By adding those two views I created a better transition between colors from first and last rows and the view controller background
    private func addBackgroundRectangles() {
        let topView = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.midY))
        topView.backgroundColor = getColorFor(0)
        view.addSubview(topView)
        view.sendSubviewToBack(topView)
        
        let bottomView = UIView(frame: CGRect(x: 0, y: view.bounds.midY, width: view.bounds.width, height: view.bounds.midY))
        bottomView.backgroundColor = getColorFor(CGFloat(1) - 1.0/CGFloat(repos.count))
        view.addSubview(bottomView)
        view.sendSubviewToBack(bottomView)
    }
}

extension ListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return repos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: ListViewCell.className) as? ListViewCell
        if cell == nil {
            cell = ListViewCell(style: .default, reuseIdentifier: ListViewCell.className)
        }
        
        cell?.updateRow(repos[indexPath.row], color: getColorFor(CGFloat(indexPath.row)/CGFloat(repos.count)))
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let url = repos[indexPath.row].html_url {
            let svc = SFSafariViewController(url: URL(string: url)!)
            svc.modalPresentationStyle = .formSheet
            svc.preferredBarTintColor = getColorFor(CGFloat(indexPath.row)/CGFloat(repos.count))
            svc.preferredControlTintColor = .white
            present(svc, animated: true, completion: nil)
        }
    }
}
