//
//  Statable.swift
//  PoqHomeTest
//
//  Created by Tom on 08/12/2021.
//

import UIKit

enum State {
    case `default`
    case loading
    case loaded
    case error
}

protocol Statable: AnyObject {
    var state: State { get set }
}
